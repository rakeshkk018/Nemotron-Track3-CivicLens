// ═══════════════════════════════════════════════════════════════
//  routes/index.js — All CivicLens API Routes
// ═══════════════════════════════════════════════════════════════

const express = require('express');
const rateLimit = require('express-rate-limit');
const router  = express.Router();

const authCtrl = require('../controllers/authController');
const docCtrl  = require('../controllers/documentController');
const chatCtrl = require('../controllers/chatController');
const { protect, requireRole, checkQuota } = require('../middleware/auth');
const { uploadSingle, uploadMultiple } = require('../middleware/upload');
const { getDBStatus } = require('../config/db');
const { verifyAPIKey, NVIDIA_MODELS } = require('../services/nvidiaService');

// ── Rate limiters ─────────────────────────────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max     : 20,
  message : { success: false, error: 'Too many auth requests. Try again in 15 minutes.' },
});

const aiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 min
  max     : parseInt(process.env.AI_RATE_LIMIT_MAX) || 20,
  message : { success: false, error: 'AI rate limit reached. Please wait a moment.' },
});

// ════════════════════════════════════════════════════════════════
//  HEALTH & SYSTEM
// ════════════════════════════════════════════════════════════════
router.get('/health', (req, res) => {
  const db   = getDBStatus();
  const nvok = !!process.env.NVIDIA_API_KEY?.startsWith('nvapi-');

  res.json({
    success  : true,
    service  : 'CivicLens AI Backend',
    version  : '2.0.0',
    timestamp: new Date().toISOString(),
    env      : process.env.NODE_ENV,
    database : db,
    nvidia   : {
      configured: nvok,
      model     : process.env.NVIDIA_MODEL || 'meta/llama-3.3-70b-instruct',
      baseUrl   : process.env.NVIDIA_API_BASE_URL,
      availableModels: NVIDIA_MODELS,
    },
    uptime   : Math.round(process.uptime()) + 's',
  });
});

// ════════════════════════════════════════════════════════════════
//  AUTH ROUTES  /api/v1/auth
// ════════════════════════════════════════════════════════════════
const auth = express.Router();

auth.post('/register',         authLimiter, authCtrl.register);
auth.post('/login',            authLimiter, authCtrl.login);
auth.post('/refresh',          authLimiter, authCtrl.refresh);
auth.get( '/me',               protect, authCtrl.getMe);
auth.put( '/me',               protect, authCtrl.updateMe);
auth.put( '/change-password',  protect, authCtrl.changePassword);

router.use('/auth', auth);

// ════════════════════════════════════════════════════════════════
//  DOCUMENT ROUTES  /api/v1/documents
// ════════════════════════════════════════════════════════════════
const docs = express.Router();

// All document routes require auth
docs.use(protect);

// Stats & search
docs.get('/stats',             docCtrl.getStats);

// Single document
docs.post(
  '/upload',
  checkQuota,
  uploadSingle,
  aiLimiter,
  docCtrl.uploadDocument
);
docs.get('/',                  docCtrl.getDocuments);
docs.get('/:id',               docCtrl.getDocument);
docs.get('/:id/status',        docCtrl.getDocumentStatus);
docs.delete('/:id',            docCtrl.deleteDocument);

// Batch multi-document
docs.post(
  '/upload-batch',
  checkQuota,
  uploadMultiple,
  aiLimiter,
  docCtrl.uploadBatch
);
docs.post('/batch/:batchId/compare', aiLimiter, docCtrl.compareBatch);

router.use('/documents', docs);

// ════════════════════════════════════════════════════════════════
//  CHAT / Q&A ROUTES  /api/v1/chat
// ════════════════════════════════════════════════════════════════
const chat = express.Router();

chat.use(protect);

chat.post('/ask',              aiLimiter, chatCtrl.askQuestion);
chat.get('/sessions',          chatCtrl.getSessions);
chat.get('/sessions/:id',      chatCtrl.getSession);
chat.delete('/sessions/:id',   chatCtrl.deleteSession);

router.use('/chat', chat);

// ════════════════════════════════════════════════════════════════
//  ADMIN ROUTES  /api/v1/admin
// ════════════════════════════════════════════════════════════════
const admin = express.Router();
admin.use(protect, requireRole('admin'));

const User     = require('../models/User');
const Document = require('../models/Document');

admin.get('/overview', async (req, res) => {
  try {
    const [users, docs, pendingDocs] = await Promise.all([
      User.countDocuments(),
      Document.countDocuments(),
      Document.countDocuments({ 'analysis.status': 'pending' }),
    ]);
    const byPlan  = await User.aggregate([{ $group: { _id: '$plan',  count: { $sum: 1 } } }]);
    const byType  = await Document.aggregate([
      { $match: { isDeleted: false } },
      { $group: { _id: '$docType', count: { $sum: 1 } } },
    ]);

    res.json({
      success: true,
      overview: {
        totalUsers: users, totalDocuments: docs, pendingAnalysis: pendingDocs,
        usersByPlan: byPlan, documentsByType: byType,
        nvidiaModel: process.env.NVIDIA_MODEL,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

admin.get('/users', async (req, res) => {
  try {
    const users = await User.find().sort({ createdAt: -1 }).limit(100).select('-password');
    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

admin.put('/users/:id/plan', async (req, res) => {
  try {
    const planLimits = { free: 20, pro: 200, enterprise: 10000 };
    const plan = req.body.plan;
    if (!planLimits[plan]) return res.status(400).json({ success: false, error: 'Invalid plan.' });

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { plan, monthlyAnalysisLimit: planLimits[plan] },
      { new: true }
    );
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.use('/admin', admin);

// ── 404 catch-all ─────────────────────────────────────────────────
router.all('*', (req, res) => {
  res.status(404).json({ success: false, error: `Route ${req.originalUrl} not found.` });
});

module.exports = router;
