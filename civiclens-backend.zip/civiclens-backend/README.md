# CivicLens AI — Backend
### Government Document Intelligence | Node.js · Express · MongoDB · NVIDIA NIM

---

## Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 18+ |
| Framework | Express 4 |
| Database | MongoDB (Mongoose 8) |
| AI Engine | **NVIDIA NIM** (`meta/llama-3.3-70b-instruct`) |
| Auth | JWT (access + refresh tokens) |
| File Parsing | pdf-parse, mammoth (DOCX), built-in (TXT) |
| Logging | Winston |
| Uploads | Multer (disk storage, dedup via SHA-256) |

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# → edit .env with your MongoDB URI and NVIDIA API key

# 3. Seed the database (creates 3 test users)
npm run seed

# 4. Start in development
npm run dev

# 5. Start in production
npm start
```

Server starts at `http://localhost:5000`

---

## Getting Your NVIDIA API Key

1. Visit **https://build.nvidia.com/**
2. Sign up / log in with an NVIDIA account
3. Click **"Get API Key"** on any model page (e.g. Llama-3.3-70B)
4. Copy your key — it starts with `nvapi-`
5. Paste it into `.env`:

```
NVIDIA_API_KEY=nvapi-YOUR_KEY_HERE
```

### Choosing a Model

Set `NVIDIA_MODEL` in `.env` to any of these:

| Model | Use Case | Speed |
|---|---|---|
| `meta/llama-3.3-70b-instruct` | Best quality (default) | Medium |
| `meta/llama-3.1-8b-instruct` | Classification tasks | Fast |
| `mistralai/mixtral-8x7b-instruct-v0.1` | Balanced | Fast |
| `nvidia/nemotron-4-340b-instruct` | Highest accuracy | Slow |
| `nv-mistralai/mistral-nemo-12b-instruct` | Multilingual | Medium |

---

## API Reference

Base URL: `http://localhost:5000/api/v1`

### Health

```
GET /health
```
Returns server status, MongoDB state, and NVIDIA config.

---

### Auth

```
POST /auth/register
Body: { name, email, password, organisation?, city? }

POST /auth/login
Body: { email, password }
Response: { accessToken, refreshToken, user }

POST /auth/refresh
Body: { refreshToken }

GET  /auth/me               ← requires Bearer token
PUT  /auth/me               ← update profile
PUT  /auth/change-password  ← { currentPassword, newPassword }
```

---

### Documents

All document routes require `Authorization: Bearer <accessToken>`

```
POST   /documents/upload         ← multipart, field: "document"
POST   /documents/upload-batch   ← multipart, field: "documents" (up to 10)
GET    /documents                ← list (page, limit, docType, status, search, tags)
GET    /documents/stats          ← usage statistics
GET    /documents/:id            ← full document + analysis
GET    /documents/:id/status     ← poll analysis progress
DELETE /documents/:id            ← soft delete
POST   /documents/batch/:batchId/compare  ← cross-doc comparison
```

**Document types auto-detected:** `council | budget | policy | emergency | scholarship | tender | gazette | other`

**Analysis status flow:** `pending → processing → completed | failed`

---

### Chat / Q&A

```
POST /chat/ask
Body: { documentId, question, sessionId? }
Response: { answer, confidence, pageRefs, sessionId }

GET    /chat/sessions         ← list sessions
GET    /chat/sessions/:id     ← full session with message history
DELETE /chat/sessions/:id     ← archive session
```

---

### Admin (role: admin only)

```
GET /admin/overview             ← platform stats
GET /admin/users                ← all users
PUT /admin/users/:id/plan       ← upgrade plan { plan: "free|pro|enterprise" }
```

---

## MongoDB Collections

| Collection | Purpose |
|---|---|
| `users` | Auth, roles, quotas |
| `documents` | Uploaded docs + AI analysis |
| `batches` | Multi-doc batch jobs |
| `chatsessions` | Per-document Q&A history |

---

## Monthly Quota System

| Plan | Monthly Analyses |
|---|---|
| free | 20 |
| pro | 200 |
| enterprise | 10,000 |

Quota resets automatically on the 1st of each month.

---

## Project Structure

```
civiclens-backend/
├── server.js               ← Express app entry point
├── .env.example            ← Environment template
├── config/
│   └── db.js               ← MongoDB connection + health
├── models/
│   ├── User.js             ← User schema + auth methods
│   ├── Document.js         ← Document schema + analysis sub-docs
│   ├── Batch.js            ← Multi-doc batch schema
│   └── ChatSession.js      ← Q&A chat history
├── routes/
│   └── index.js            ← All API routes
├── controllers/
│   ├── authController.js   ← Register, login, refresh, me
│   ├── documentController.js ← Upload, analyze, CRUD, batch
│   └── chatController.js   ← Q&A via NVIDIA NIM
├── middleware/
│   ├── auth.js             ← JWT protect, requireRole, checkQuota
│   └── upload.js           ← Multer config
├── services/
│   ├── nvidiaService.js    ← NVIDIA NIM API (classify, analyze, chat, compare)
│   └── extractorService.js ← PDF/DOCX/TXT text extraction
└── utils/
    ├── logger.js           ← Winston logger
    └── seed.js             ← DB seed script
```

---

## Connecting to the CivicLens Frontend

Add this to your HTML before the closing `</body>`:

```javascript
const CIVICLENS_API = 'http://localhost:5000/api/v1';

// Login
const { accessToken } = await fetch(`${CIVICLENS_API}/auth/login`, {
  method : 'POST',
  headers: { 'Content-Type': 'application/json' },
  body   : JSON.stringify({ email, password }),
}).then(r => r.json());

// Upload document
const form = new FormData();
form.append('document', fileInput.files[0]);
const { document } = await fetch(`${CIVICLENS_API}/documents/upload`, {
  method : 'POST',
  headers: { 'Authorization': `Bearer ${accessToken}` },
  body   : form,
}).then(r => r.json());

// Poll until ready
const poll = setInterval(async () => {
  const { status } = await fetch(`${CIVICLENS_API}/documents/${document._id}/status`, {
    headers: { 'Authorization': `Bearer ${accessToken}` },
  }).then(r => r.json());
  if (status === 'completed') clearInterval(poll);
}, 2000);

// Ask a question
const { answer } = await fetch(`${CIVICLENS_API}/chat/ask`, {
  method : 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${accessToken}` },
  body   : JSON.stringify({ documentId: document._id, question: 'Who is affected?' }),
}).then(r => r.json());
```

---

## Security Notes

- JWT secrets should be long random strings in production (not the defaults)
- NVIDIA API key is server-side only — never expose it to the frontend
- File uploads are stored server-side; serve them through authenticated routes in production
- Rate limiting is applied globally and per-AI-endpoint
- Passwords are bcrypt-hashed with 12 rounds
