// ═══════════════════════════════════════════════════════════════
//  config/db.js — MongoDB Connection (CivicLens AI)
// ═══════════════════════════════════════════════════════════════

const mongoose = require('mongoose');
const logger   = require('../utils/logger');

// ── Connection options ───────────────────────────────────────────
const mongoOptions = {
  maxPoolSize     : parseInt(process.env.MONGODB_MAX_POOL_SIZE) || 10,
  minPoolSize     : parseInt(process.env.MONGODB_MIN_POOL_SIZE) || 2,
  serverSelectionTimeoutMS : 10_000,
  socketTimeoutMS          : 45_000,
  connectTimeoutMS         : 10_000,
  heartbeatFrequencyMS     : 10_000,
  retryWrites              : true,
  retryReads               : true,
};

// ── Stats helper ─────────────────────────────────────────────────
const dbStats = {
  connected  : false,
  reconnects : 0,
  uri        : '',
};

// ── Connect ──────────────────────────────────────────────────────
const connectDB = async () => {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error('MONGODB_URI is not defined in environment variables');

  // Mask password for logging
  dbStats.uri = uri.replace(/:([^@]+)@/, ':****@');

  try {
    mongoose.set('strictQuery', true);

    await mongoose.connect(uri, mongoOptions);

    dbStats.connected = true;

    logger.info(`✅ MongoDB connected → ${dbStats.uri}`);
    logger.info(`   Pool: min=${mongoOptions.minPoolSize} / max=${mongoOptions.maxPoolSize}`);

    return mongoose.connection;
  } catch (err) {
    logger.error(`❌ MongoDB connection failed: ${err.message}`);
    process.exit(1);
  }
};

// ── Event listeners ──────────────────────────────────────────────
mongoose.connection.on('disconnected', () => {
  dbStats.connected = false;
  logger.warn('⚠️  MongoDB disconnected');
});

mongoose.connection.on('reconnected', () => {
  dbStats.connected  = true;
  dbStats.reconnects += 1;
  logger.info(`🔄 MongoDB reconnected (attempt #${dbStats.reconnects})`);
});

mongoose.connection.on('error', (err) => {
  logger.error(`MongoDB error: ${err.message}`);
});

// ── Graceful shutdown ────────────────────────────────────────────
const gracefulClose = async () => {
  await mongoose.connection.close();
  dbStats.connected = false;
  logger.info('MongoDB connection closed gracefully');
};

process.on('SIGINT',  gracefulClose);
process.on('SIGTERM', gracefulClose);

// ── Health check helper ───────────────────────────────────────────
const getDBStatus = () => ({
  connected  : dbStats.connected,
  reconnects : dbStats.reconnects,
  uri        : dbStats.uri,
  readyState : mongoose.connection.readyState,
  // 0=disconnected, 1=connected, 2=connecting, 3=disconnecting
  stateLabel : ['disconnected','connected','connecting','disconnecting'][mongoose.connection.readyState] || 'unknown',
});

module.exports = { connectDB, getDBStatus };
