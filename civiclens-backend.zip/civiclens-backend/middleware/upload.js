// ═══════════════════════════════════════════════════════════════
//  middleware/upload.js — Multer File Upload Config
// ═══════════════════════════════════════════════════════════════

const multer = require('multer');
const path   = require('path');
const fs     = require('fs');
const { v4: uuidv4 } = require('uuid');

const UPLOAD_DIR    = process.env.UPLOAD_DIR || './uploads';
const MAX_SIZE_MB   = parseInt(process.env.MAX_FILE_SIZE_MB) || 50;
const ALLOWED_TYPES = (process.env.ALLOWED_FILE_TYPES || 'pdf,doc,docx,txt').split(',').map(t => t.trim());

// Ensure upload directory exists
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ── Disk storage ──────────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename   : (_req, file, cb) => {
    const ext  = path.extname(file.originalname).toLowerCase();
    const uuid = uuidv4();
    cb(null, `${uuid}${ext}`);
  },
});

// ── MIME filter ───────────────────────────────────────────────────
const fileFilter = (_req, file, cb) => {
  const ext      = path.extname(file.originalname).toLowerCase().replace('.', '');
  const mimeOk   = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
  ].includes(file.mimetype);

  if (ALLOWED_TYPES.includes(ext) && mimeOk) {
    cb(null, true);
  } else {
    cb(new Error(`File type not allowed. Accepted: ${ALLOWED_TYPES.join(', ')}`), false);
  }
};

// ── Single document upload ────────────────────────────────────────
const uploadSingle = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_SIZE_MB * 1024 * 1024 },
}).single('document');

// ── Multi document upload (up to 10) ─────────────────────────────
const uploadMultiple = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_SIZE_MB * 1024 * 1024 },
}).array('documents', 10);

// ── Wrap multer to return clean errors ────────────────────────────
const wrapMulter = (uploader) => (req, res, next) => {
  uploader(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({
          success: false,
          error  : `File too large. Maximum size is ${MAX_SIZE_MB} MB.`,
        });
      }
      return res.status(400).json({ success: false, error: err.message });
    }
    return res.status(400).json({ success: false, error: err.message });
  });
};

module.exports = {
  uploadSingle  : wrapMulter(uploadSingle),
  uploadMultiple: wrapMulter(uploadMultiple),
};
