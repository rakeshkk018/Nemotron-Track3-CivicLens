// ═══════════════════════════════════════════════════════════════
//  middleware/auth.js — JWT Auth Middleware
// ═══════════════════════════════════════════════════════════════

const jwt    = require('jsonwebtoken');
const User   = require('../models/User');
const logger = require('../utils/logger');

// ── Protect route: require valid JWT ─────────────────────────────
const protect = async (req, res, next) => {
  let token;

  // 1. Check Authorization header
  if (req.headers.authorization?.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  // 2. Check cookie (optional)
  else if (req.cookies?.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      error  : 'Access denied. No token provided.',
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user    = await User.findById(decoded.id).select('-password -refreshToken');

    if (!user) {
      return res.status(401).json({ success: false, error: 'User not found.' });
    }
    if (!user.isActive) {
      return res.status(401).json({ success: false, error: 'Account is deactivated.' });
    }

    req.user = user;
    next();
  } catch (err) {
    logger.warn(`Invalid JWT: ${err.message}`);
    return res.status(401).json({
      success: false,
      error  : 'Invalid or expired token.',
    });
  }
};

// ── Optional auth: attach user if token is valid (no fail) ────────
const optionalAuth = async (req, res, next) => {
  let token = req.headers.authorization?.startsWith('Bearer ')
    ? req.headers.authorization.split(' ')[1]
    : null;

  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password -refreshToken');
    } catch (_) {
      req.user = null;
    }
  }
  next();
};

// ── Role guard ────────────────────────────────────────────────────
const requireRole = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user?.role)) {
    return res.status(403).json({
      success: false,
      error  : `Access denied. Required role(s): ${roles.join(', ')}.`,
    });
  }
  next();
};

// ── Quota guard: check monthly analysis limit ─────────────────────
const checkQuota = async (req, res, next) => {
  if (!req.user.hasAnalysisQuota()) {
    return res.status(429).json({
      success: false,
      error  : `Monthly analysis limit reached (${req.user.monthlyAnalysisLimit}). Upgrade your plan.`,
      usage  : {
        used : req.user.monthlyAnalysisCount,
        limit: req.user.monthlyAnalysisLimit,
        plan : req.user.plan,
      },
    });
  }
  next();
};

// ── Token generator ───────────────────────────────────────────────
const generateTokens = (userId) => {
  const access = jwt.sign(
    { id: userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
  const refresh = jwt.sign(
    { id: userId },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' }
  );
  return { access, refresh };
};

module.exports = { protect, optionalAuth, requireRole, checkQuota, generateTokens };
