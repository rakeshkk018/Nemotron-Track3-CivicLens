// ═══════════════════════════════════════════════════════════════
//  utils/seed.js — Seed CivicLens DB with test data
//  Usage: node utils/seed.js
// ═══════════════════════════════════════════════════════════════

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });

const mongoose = require('mongoose');
const User     = require('../models/User');
const logger   = require('./logger');

const SEED_USERS = [
  {
    name    : 'Admin User',
    email   : 'admin@civiclens.ai',
    password: 'Admin@12345',
    role    : 'admin',
    plan    : 'enterprise',
    monthlyAnalysisLimit: 10000,
    organisation: 'CivicLens AI',
    city    : 'Bengaluru',
  },
  {
    name    : 'Analyst Demo',
    email   : 'analyst@civiclens.ai',
    password: 'Analyst@123',
    role    : 'analyst',
    plan    : 'pro',
    monthlyAnalysisLimit: 200,
    organisation: 'BBMP Analytics',
    city    : 'Bengaluru',
  },
  {
    name    : 'Citizen Demo',
    email   : 'citizen@civiclens.ai',
    password: 'Citizen@123',
    role    : 'citizen',
    plan    : 'free',
    monthlyAnalysisLimit: 20,
    city    : 'Bengaluru',
  },
];

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    logger.info('Connected to MongoDB for seeding');

    await User.deleteMany({});
    logger.info('Cleared existing users');

    const created = await User.insertMany(SEED_USERS);
    logger.info(`✅ Seeded ${created.length} users:`);

    created.forEach(u => {
      logger.info(`   • ${u.email} | role=${u.role} | plan=${u.plan}`);
    });

    logger.info('\n🔑 Test credentials:');
    logger.info('   Admin   → admin@civiclens.ai   / Admin@12345');
    logger.info('   Analyst → analyst@civiclens.ai / Analyst@123');
    logger.info('   Citizen → citizen@civiclens.ai / Citizen@123');

    await mongoose.disconnect();
    logger.info('\nDone. Disconnected from MongoDB.');
    process.exit(0);
  } catch (err) {
    logger.error(`Seed error: ${err.message}`);
    process.exit(1);
  }
};

seed();
