// ═══════════════════════════════════════════════════════════════
//  utils/logger.js — Winston Logger
// ═══════════════════════════════════════════════════════════════

const { createLogger, format, transports } = require('winston');
const path = require('path');
const fs   = require('fs');

// Ensure logs directory exists
const logDir = path.dirname(process.env.LOG_FILE || './logs/civiclens.log');
if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

const { combine, timestamp, colorize, printf, json, errors } = format;

// ── Console format ──────────────────────────────────────────────
const consoleFormat = printf(({ level, message, timestamp, stack }) => {
  const base = `${timestamp}  [${level.toUpperCase()}]  ${stack || message}`;
  return base;
});

// ── Logger instance ─────────────────────────────────────────────
const logger = createLogger({
  level : process.env.LOG_LEVEL || 'info',
  format: combine(
    errors({ stack: true }),
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    json()
  ),
  transports: [
    // Console — colourised in dev, plain in prod
    new transports.Console({
      format: process.env.NODE_ENV === 'production'
        ? combine(timestamp({ format: 'HH:mm:ss' }), consoleFormat)
        : combine(colorize(), timestamp({ format: 'HH:mm:ss' }), consoleFormat),
    }),
    // Rotating file — all levels
    new transports.File({
      filename : process.env.LOG_FILE || './logs/civiclens.log',
      maxsize  : 10 * 1024 * 1024, // 10 MB
      maxFiles : 5,
      tailable : true,
    }),
    // Separate error file
    new transports.File({
      filename : path.join(logDir, 'errors.log'),
      level    : 'error',
      maxsize  : 5 * 1024 * 1024,
      maxFiles : 3,
    }),
  ],
});

module.exports = logger;
