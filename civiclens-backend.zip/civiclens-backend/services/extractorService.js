// ═══════════════════════════════════════════════════════════════
//  services/extractorService.js — File Text Extraction
// ═══════════════════════════════════════════════════════════════

const path    = require('path');
const fs      = require('fs');
const crypto  = require('crypto');
const logger  = require('../utils/logger');

// ── Extract text from any supported file type ─────────────────────
const extractText = async (filePath, mimeType) => {
  const ext = path.extname(filePath).toLowerCase();

  try {
    if (mimeType === 'application/pdf' || ext === '.pdf') {
      return await extractPDF(filePath);
    }
    if (
      mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
      ext === '.docx'
    ) {
      return await extractDOCX(filePath);
    }
    if (mimeType === 'text/plain' || ext === '.txt') {
      return await extractTXT(filePath);
    }
    throw new Error(`Unsupported file type: ${mimeType || ext}`);
  } catch (err) {
    logger.error(`Text extraction failed for ${filePath}: ${err.message}`);
    throw err;
  }
};

// ── PDF extraction ────────────────────────────────────────────────
const extractPDF = async (filePath) => {
  const pdfParse = require('pdf-parse');
  const buffer   = fs.readFileSync(filePath);
  const data     = await pdfParse(buffer);

  return {
    text     : data.text || '',
    pageCount: data.numpages || 0,
    wordCount: (data.text || '').split(/\s+/).filter(Boolean).length,
  };
};

// ── DOCX extraction ───────────────────────────────────────────────
const extractDOCX = async (filePath) => {
  const mammoth = require('mammoth');
  const result  = await mammoth.extractRawText({ path: filePath });

  return {
    text     : result.value || '',
    pageCount: Math.ceil((result.value || '').split(/\s+/).length / 250), // ~250 words/page
    wordCount: (result.value || '').split(/\s+/).filter(Boolean).length,
  };
};

// ── TXT extraction ────────────────────────────────────────────────
const extractTXT = async (filePath) => {
  const text = fs.readFileSync(filePath, 'utf-8');
  return {
    text     : text,
    pageCount: Math.ceil(text.split(/\s+/).length / 250),
    wordCount: text.split(/\s+/).filter(Boolean).length,
  };
};

// ── Chunk text for RAG (1000 tokens ~= 4000 chars) ────────────────
const chunkText = (text, chunkSize = 4000) => {
  const chunks = [];
  for (let i = 0; i < text.length; i += chunkSize) {
    chunks.push(text.slice(i, i + chunkSize));
  }
  return chunks;
};

// ── Compute SHA-256 hash for deduplication ────────────────────────
const computeFileHash = (filePath) => {
  const hash   = crypto.createHash('sha256');
  const stream = fs.createReadStream(filePath);
  return new Promise((resolve, reject) => {
    stream.on('data', d  => hash.update(d));
    stream.on('end',  ()  => resolve(hash.digest('hex')));
    stream.on('error', e  => reject(e));
  });
};

module.exports = { extractText, chunkText, computeFileHash };
