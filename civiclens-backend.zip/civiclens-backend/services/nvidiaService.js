// ═══════════════════════════════════════════════════════════════
//  services/nvidiaService.js — NVIDIA NIM API Integration
// ═══════════════════════════════════════════════════════════════

const logger = require('../utils/logger');

// ── Config ────────────────────────────────────────────────────────
const NVIDIA_API_BASE = process.env.NVIDIA_API_BASE_URL || 'https://integrate.api.nvidia.com/v1';
const NVIDIA_API_KEY  = process.env.NVIDIA_API_KEY;
const DEFAULT_MODEL   = process.env.NVIDIA_MODEL || 'meta/llama-3.3-70b-instruct';
const MAX_TOKENS      = parseInt(process.env.NVIDIA_MAX_TOKENS) || 2048;
const TEMPERATURE     = parseFloat(process.env.NVIDIA_TEMPERATURE) || 0.2;
const TOP_P           = parseFloat(process.env.NVIDIA_TOP_P) || 0.95;

// ── Available NVIDIA NIM models ───────────────────────────────────
const NVIDIA_MODELS = {
  llama_70b      : 'meta/llama-3.3-70b-instruct',
  llama_8b       : 'meta/llama-3.1-8b-instruct',
  mixtral_8x7b   : 'mistralai/mixtral-8x7b-instruct-v0.1',
  nemotron_340b  : 'nvidia/nemotron-4-340b-instruct',
  mistral_nemo   : 'nv-mistralai/mistral-nemo-12b-instruct',
};

// ── Raw API call ──────────────────────────────────────────────────
const callNvidiaAPI = async ({
  messages,
  model      = DEFAULT_MODEL,
  maxTokens  = MAX_TOKENS,
  temperature= TEMPERATURE,
  topP       = TOP_P,
  stream     = false,
}) => {
  if (!NVIDIA_API_KEY) {
    throw new Error('NVIDIA_API_KEY is not configured. Set it in your .env file.');
  }

  const payload = {
    model,
    messages,
    max_tokens : maxTokens,
    temperature,
    top_p      : topP,
    stream,
  };

  const startTime = Date.now();

  try {
    const { default: fetch } = await import('node-fetch');

    const response = await fetch(`${NVIDIA_API_BASE}/chat/completions`, {
      method : 'POST',
      headers: {
        'Content-Type'  : 'application/json',
        'Authorization' : `Bearer ${NVIDIA_API_KEY}`,
        'Accept'        : 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errBody = await response.text();
      throw new Error(`NVIDIA API error ${response.status}: ${errBody}`);
    }

    const data = await response.json();
    const ms   = Date.now() - startTime;

    logger.info(`NVIDIA API call: model=${model}, tokens=${data.usage?.total_tokens || 0}, ms=${ms}`);

    return {
      content    : data.choices?.[0]?.message?.content || '',
      usage      : data.usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
      model      : data.model || model,
      processingMs: ms,
    };
  } catch (err) {
    logger.error(`NVIDIA API call failed: ${err.message}`);
    throw err;
  }
};

// ════════════════════════════════════════════════════════════════
//  DOCUMENT CLASSIFICATION
// ════════════════════════════════════════════════════════════════
const classifyDocument = async (rawText) => {
  const snippet = rawText.slice(0, 1500);

  const result = await callNvidiaAPI({
    model: NVIDIA_MODELS.llama_8b,  // faster/cheaper for classification
    maxTokens: 200,
    temperature: 0,
    messages: [
      {
        role   : 'system',
        content: `You are a government document classifier. Respond ONLY with a JSON object.
No markdown, no explanation — just raw JSON.
Schema: {"type": "<one of: council|budget|policy|emergency|scholarship|tender|gazette|other>",
         "language": "<ISO 639-1 code>",
         "confidence": <0-100>}`,
      },
      {
        role   : 'user',
        content: `Classify this document:\n\n${snippet}`,
      },
    ],
  });

  try {
    return JSON.parse(result.content.trim());
  } catch {
    return { type: 'other', language: 'en', confidence: 50 };
  }
};

// ════════════════════════════════════════════════════════════════
//  FULL DOCUMENT ANALYSIS
// ════════════════════════════════════════════════════════════════
const analyzeDocument = async (rawText, docType = 'other', docName = '') => {
  // Truncate to ~6000 tokens (~24000 chars) to stay within context
  const textForAnalysis = rawText.slice(0, 24_000);

  const systemPrompt = `You are CivicLens AI, an expert analyst of Indian government documents.
Your role: extract key information accurately, cite page/section references, and remove all bias.
Always respond with a single valid JSON object — no markdown fences, no extra text.

JSON Schema:
{
  "quickSummary": "<1–2 sentence plain-language summary for citizens>",
  "factualSummary": "<detailed factual summary with inline [p.N §N] citations>",
  "biasFlags": ["<phrase that was flagged as biased and removed>"],
  "overallConfidence": <0-100>,
  "keyDecisions": [
    { "title": "", "summary": "", "vote": "", "effectiveDate": "", "pageRef": "" }
  ],
  "actionItems": [
    { "title": "", "description": "", "deadline": "", "priority": "high|medium|low", "affectedGroup": "", "pageRef": "" }
  ],
  "alerts": [
    { "level": "info|warning|critical", "message": "", "pageRef": "" }
  ],
  "entities": [
    { "text": "", "type": "date|amount|org|person|location|law|other", "confidence": 0.95 }
  ]
}`;

  const userPrompt = `Document Name: "${docName}"
Document Type: ${docType}

Full Text:
${textForAnalysis}

Analyse this document and return the JSON object.`;

  const result = await callNvidiaAPI({
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user',   content: userPrompt },
    ],
  });

  let parsed;
  try {
    // Strip potential markdown fences if any
    const cleaned = result.content.replace(/^```json?\s*/i, '').replace(/```\s*$/i, '').trim();
    parsed = JSON.parse(cleaned);
  } catch (err) {
    logger.warn(`JSON parse failed for analysis, using fallback: ${err.message}`);
    parsed = buildFallbackAnalysis(docName);
  }

  // Normalise counts
  parsed.decisionCount = (parsed.keyDecisions || []).length;
  parsed.actionCount   = (parsed.actionItems   || []).length;
  parsed.alertCount    = (parsed.alerts        || []).length;
  parsed.tokensUsed    = {
    prompt    : result.usage.prompt_tokens,
    completion: result.usage.completion_tokens,
    total     : result.usage.total_tokens,
  };
  parsed.model       = result.model;
  parsed.processingMs= result.processingMs;

  return parsed;
};

// ════════════════════════════════════════════════════════════════
//  DOCUMENT Q&A (RAG-style)
// ════════════════════════════════════════════════════════════════
const answerQuestion = async ({
  question,
  documentContext,
  docName,
  conversationHistory = [],
}) => {
  const context = documentContext.slice(0, 18_000);

  const systemPrompt = `You are CivicLens AI, an expert at answering questions about Indian government documents.
Only answer from the provided document context. Cite page and section references like [p.N §N].
If the answer is not in the document, say "This information is not found in the provided document."
Keep answers concise, factual, and in plain language suitable for Indian citizens.
Include a confidence score (0–100) based on how clearly the document addresses the question.
Respond as JSON: { "answer": "<answer text with [p.N §N] citations>", "confidence": <0-100>, "pageRefs": ["p.2 §3"] }`;

  const messages = [
    { role: 'system', content: systemPrompt },
    // Include last 4 conversation turns for context
    ...conversationHistory.slice(-8).map(m => ({ role: m.role, content: m.content })),
    {
      role   : 'user',
      content: `Document: "${docName}"\n\nContext:\n${context}\n\nQuestion: ${question}`,
    },
  ];

  const result = await callNvidiaAPI({ messages, maxTokens: 1024 });

  try {
    const cleaned = result.content.replace(/^```json?\s*/i, '').replace(/```\s*$/i, '').trim();
    const parsed  = JSON.parse(cleaned);
    return {
      answer    : parsed.answer || result.content,
      confidence: parsed.confidence || 85,
      pageRefs  : parsed.pageRefs  || [],
      tokensUsed: result.usage.total_tokens,
    };
  } catch {
    return {
      answer    : result.content,
      confidence: 80,
      pageRefs  : [],
      tokensUsed: result.usage.total_tokens,
    };
  }
};

// ════════════════════════════════════════════════════════════════
//  MULTI-DOCUMENT COMPARISON
// ════════════════════════════════════════════════════════════════
const compareDocuments = async (documents) => {
  // Build a cross-document summary from individual quickSummaries
  const docSummaries = documents.map((d, i) =>
    `Document ${i + 1}: "${d.originalName}" (${d.docType})\n${d.analysis?.quickSummary || 'No summary available.'}`
  ).join('\n\n---\n\n');

  const result = await callNvidiaAPI({
    messages: [
      {
        role   : 'system',
        content: `You are CivicLens AI performing cross-document analysis of Indian government documents.
Identify common themes, conflicts, and combined action items.
Respond ONLY with JSON:
{
  "crossDocSummary": "<2-3 sentence overall summary>",
  "commonThemes": ["<theme>"],
  "conflictingClauses": ["<conflict description>"],
  "combinedDecisions": <count>,
  "combinedActions": <count>,
  "combinedAlerts": <count>,
  "averageConfidence": <0-100>
}`,
      },
      {
        role   : 'user',
        content: `Analyse these ${documents.length} documents together:\n\n${docSummaries}`,
      },
    ],
  });

  try {
    const cleaned = result.content.replace(/^```json?\s*/i, '').replace(/```\s*$/i, '').trim();
    return JSON.parse(cleaned);
  } catch {
    return {
      crossDocSummary   : `${documents.length} documents analysed. See individual summaries for details.`,
      commonThemes      : [],
      conflictingClauses: [],
      combinedDecisions : documents.reduce((s, d) => s + (d.analysis?.decisionCount || 0), 0),
      combinedActions   : documents.reduce((s, d) => s + (d.analysis?.actionCount   || 0), 0),
      combinedAlerts    : documents.reduce((s, d) => s + (d.analysis?.alertCount    || 0), 0),
      averageConfidence : 85,
    };
  }
};

// ════════════════════════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════════════════════════
const buildFallbackAnalysis = (docName) => ({
  quickSummary     : `Document "${docName}" processed. Review key sections below.`,
  factualSummary   : `Document "${docName}" analysed. Structured extraction completed.`,
  biasFlags        : [],
  overallConfidence: 75,
  keyDecisions     : [],
  actionItems      : [],
  alerts           : [],
  entities         : [],
});

// Verify NVIDIA API key is set (called at startup)
const verifyAPIKey = () => {
  if (!NVIDIA_API_KEY) {
    logger.warn('⚠️  NVIDIA_API_KEY is not set. AI analysis features will fail.');
    return false;
  }
  if (!NVIDIA_API_KEY.startsWith('nvapi-')) {
    logger.warn('⚠️  NVIDIA_API_KEY format looks incorrect. Expected prefix: nvapi-');
    return false;
  }
  logger.info(`✅ NVIDIA NIM configured → model=${DEFAULT_MODEL}`);
  return true;
};

module.exports = {
  callNvidiaAPI,
  classifyDocument,
  analyzeDocument,
  answerQuestion,
  compareDocuments,
  verifyAPIKey,
  NVIDIA_MODELS,
};
