// ═══════════════════════════════════════════════════════════════
//  controllers/documentController.js — Document Management
// ═══════════════════════════════════════════════════════════════

const path     = require('path');
const fs       = require('fs');
const Document = require('../models/Document');
const Batch    = require('../models/Batch');
const logger   = require('../utils/logger');
const { extractText, chunkText, computeFileHash } = require('../services/extractorService');
const { classifyDocument, analyzeDocument, compareDocuments } = require('../services/nvidiaService');

// ── POST /documents/upload — single doc ───────────────────────────
exports.uploadDocument = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'No file uploaded.' });
    }

    const { originalname, filename, path: filePath, size, mimetype } = req.file;

    // Compute hash for deduplication
    const fileHash = await computeFileHash(filePath);

    // Check for duplicate (same hash, same user, not deleted)
    const duplicate = await Document.findOne({ fileHash, uploadedBy: req.user._id });
    if (duplicate) {
      fs.unlinkSync(filePath); // remove duplicate file
      return res.status(409).json({
        success   : false,
        error     : 'This document has already been uploaded.',
        documentId: duplicate._id,
      });
    }

    // Extract text
    const { text, pageCount, wordCount } = await extractText(filePath, mimetype);
    const chunks = chunkText(text);

    // Classify document type via NVIDIA
    const classification = await classifyDocument(text);

    // Create document record (analysis starts as 'pending')
    const doc = await Document.create({
      originalName    : originalname,
      storedName      : filename,
      filePath,
      fileSize        : size,
      mimeType        : mimetype,
      fileHash,
      docType         : classification.type,
      language        : classification.language,
      pageCount,
      wordCount,
      rawText         : text,
      extractedChunks : chunks,
      uploadedBy      : req.user._id,
      tags            : req.body.tags ? req.body.tags.split(',').map(t => t.trim()) : [],
      'analysis.status': 'processing',
    });

    // ── Trigger async AI analysis ─────────────────────────────────
    // Fire-and-forget — client polls GET /documents/:id
    analyzeDocumentAsync(doc._id, text, classification.type, originalname, req.user);

    res.status(201).json({
      success: true,
      message: 'Document uploaded. AI analysis in progress…',
      document: {
        _id        : doc._id,
        originalName: doc.originalName,
        docType    : doc.docType,
        pageCount  : doc.pageCount,
        wordCount  : doc.wordCount,
        status     : 'processing',
        createdAt  : doc.createdAt,
      },
    });
  } catch (err) {
    logger.error(`Upload error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Document upload failed.' });
  }
};

// ── Async analysis runner ─────────────────────────────────────────
const analyzeDocumentAsync = async (docId, text, docType, docName, user) => {
  try {
    const result = await analyzeDocument(text, docType, docName);

    await Document.findByIdAndUpdate(docId, {
      'analysis.status'         : 'completed',
      'analysis.completedAt'    : new Date(),
      'analysis.model'          : result.model,
      'analysis.processingMs'   : result.processingMs,
      'analysis.quickSummary'   : result.quickSummary,
      'analysis.factualSummary' : result.factualSummary,
      'analysis.biasFlags'      : result.biasFlags,
      'analysis.overallConfidence': result.overallConfidence,
      'analysis.keyDecisions'   : result.keyDecisions,
      'analysis.actionItems'    : result.actionItems,
      'analysis.alerts'         : result.alerts,
      'analysis.entities'       : result.entities,
      'analysis.decisionCount'  : result.decisionCount,
      'analysis.actionCount'    : result.actionCount,
      'analysis.alertCount'     : result.alertCount,
      'analysis.tokensUsed'     : result.tokensUsed,
    });

    // Increment user's monthly usage
    await user.incrementUsage();

    logger.info(`Analysis complete for doc ${docId} (${result.processingMs}ms)`);
  } catch (err) {
    await Document.findByIdAndUpdate(docId, {
      'analysis.status'      : 'failed',
      'analysis.errorMessage': err.message,
    });
    logger.error(`Analysis failed for doc ${docId}: ${err.message}`);
  }
};

// ── POST /documents/upload-batch ─────────────────────────────────
exports.uploadBatch = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, error: 'No files uploaded.' });
    }

    const batch = await Batch.create({
      name     : req.body.batchName || `Batch — ${new Date().toLocaleDateString()}`,
      createdBy: req.user._id,
      docCount : req.files.length,
      status   : 'processing',
    });

    const uploadPromises = req.files.map(async (file) => {
      const { originalname, filename, path: filePath, size, mimetype } = file;
      const fileHash = await computeFileHash(filePath);
      const { text, pageCount, wordCount } = await extractText(filePath, mimetype);
      const chunks = chunkText(text);
      const classification = await classifyDocument(text);

      const doc = await Document.create({
        originalName    : originalname,
        storedName      : filename,
        filePath,
        fileSize        : size,
        mimeType        : mimetype,
        fileHash,
        docType         : classification.type,
        pageCount,
        wordCount,
        rawText         : text,
        extractedChunks : chunks,
        uploadedBy      : req.user._id,
        batchId         : batch._id,
        'analysis.status': 'processing',
      });

      analyzeDocumentAsync(doc._id, text, classification.type, originalname, req.user);
      return doc._id;
    });

    const docIds = await Promise.all(uploadPromises);

    await Batch.findByIdAndUpdate(batch._id, { documentIds: docIds });

    res.status(201).json({
      success: true,
      message: `${docIds.length} documents uploaded. AI analysis in progress…`,
      batchId: batch._id,
      documentIds: docIds,
    });
  } catch (err) {
    logger.error(`Batch upload error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Batch upload failed.' });
  }
};

// ── GET /documents — list user docs ───────────────────────────────
exports.getDocuments = async (req, res) => {
  try {
    const { page = 1, limit = 10, docType, status, search, tags } = req.query;

    const filter = { uploadedBy: req.user._id };

    if (docType) filter.docType = docType;
    if (status)  filter['analysis.status'] = status;
    if (tags)    filter.tags = { $in: tags.split(',').map(t => t.trim()) };
    if (search) {
      filter.$or = [
        { originalName      : { $regex: search, $options: 'i' } },
        { 'analysis.quickSummary': { $regex: search, $options: 'i' } },
        { tags              : { $regex: search, $options: 'i' } },
      ];
    }

    const options = {
      page    : parseInt(page),
      limit   : parseInt(limit),
      sort    : { createdAt: -1 },
      select  : '-rawText -extractedChunks',
      populate: { path: 'uploadedBy', select: 'name email' },
    };

    const result = await Document.paginate(filter, options);

    res.json({
      success    : true,
      documents  : result.docs,
      total      : result.totalDocs,
      pages      : result.totalPages,
      currentPage: result.page,
    });
  } catch (err) {
    logger.error(`Get documents error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Failed to fetch documents.' });
  }
};

// ── GET /documents/:id ────────────────────────────────────────────
exports.getDocument = async (req, res) => {
  try {
    const doc = await Document.findOne({
      _id       : req.params.id,
      uploadedBy: req.user._id,
    }).select('-rawText -extractedChunks');

    if (!doc) {
      return res.status(404).json({ success: false, error: 'Document not found.' });
    }

    // Increment view count
    await Document.findByIdAndUpdate(doc._id, { $inc: { viewCount: 1 } });

    res.json({ success: true, document: doc });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch document.' });
  }
};

// ── GET /documents/:id/status — poll analysis status ─────────────
exports.getDocumentStatus = async (req, res) => {
  try {
    const doc = await Document.findOne({
      _id       : req.params.id,
      uploadedBy: req.user._id,
    }).select('analysis.status analysis.completedAt analysis.errorMessage analysis.overallConfidence');

    if (!doc) {
      return res.status(404).json({ success: false, error: 'Document not found.' });
    }

    res.json({
      success   : true,
      status    : doc.analysis.status,
      confidence: doc.analysis.overallConfidence,
      completedAt: doc.analysis.completedAt,
      error     : doc.analysis.errorMessage,
    });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Status check failed.' });
  }
};

// ── DELETE /documents/:id ─────────────────────────────────────────
exports.deleteDocument = async (req, res) => {
  try {
    const doc = await Document.findOne({ _id: req.params.id, uploadedBy: req.user._id });

    if (!doc) {
      return res.status(404).json({ success: false, error: 'Document not found.' });
    }

    await doc.softDelete();

    res.json({ success: true, message: 'Document deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Delete failed.' });
  }
};

// ── GET /documents/stats — user analytics ─────────────────────────
exports.getStats = async (req, res) => {
  try {
    const userId = req.user._id;

    const [totalDocs, byType, totalTokens] = await Promise.all([
      Document.countDocuments({ uploadedBy: userId }),
      Document.aggregate([
        { $match: { uploadedBy: userId, isDeleted: false } },
        { $group: { _id: '$docType', count: { $sum: 1 } } },
      ]),
      Document.aggregate([
        { $match: { uploadedBy: userId, isDeleted: false } },
        { $group: { _id: null, total: { $sum: '$analysis.tokensUsed.total' } } },
      ]),
    ]);

    res.json({
      success: true,
      stats  : {
        totalDocuments  : totalDocs,
        byDocType       : byType,
        totalTokensUsed : totalTokens[0]?.total || 0,
        monthlyUsage    : req.user.monthlyAnalysisCount,
        monthlyLimit    : req.user.monthlyAnalysisLimit,
        plan            : req.user.plan,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Stats fetch failed.' });
  }
};

// ── POST /documents/batch/:batchId/compare — cross-doc analysis ───
exports.compareBatch = async (req, res) => {
  try {
    const batch = await Batch.findOne({
      _id      : req.params.batchId,
      createdBy: req.user._id,
    });

    if (!batch) {
      return res.status(404).json({ success: false, error: 'Batch not found.' });
    }

    const docs = await Document.find({
      _id       : { $in: batch.documentIds },
      'analysis.status': 'completed',
    }).select('-rawText -extractedChunks');

    if (docs.length < 2) {
      return res.status(400).json({
        success: false,
        error  : 'At least 2 analysed documents are required for comparison.',
      });
    }

    const merged = await compareDocuments(docs);

    await Batch.findByIdAndUpdate(batch._id, {
      mergedAnalysis: merged,
      status        : 'completed',
      completedAt   : new Date(),
    });

    res.json({ success: true, batchId: batch._id, mergedAnalysis: merged, documentCount: docs.length });
  } catch (err) {
    logger.error(`Batch compare error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Batch comparison failed.' });
  }
};
