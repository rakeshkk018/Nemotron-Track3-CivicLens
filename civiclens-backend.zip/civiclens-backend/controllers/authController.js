// ═══════════════════════════════════════════════════════════════
//  controllers/authController.js — Authentication
// ═══════════════════════════════════════════════════════════════

const jwt    = require('jsonwebtoken');
const User   = require('../models/User');
const logger = require('../utils/logger');
const { generateTokens } = require('../middleware/auth');

// ── Helper: send token response ───────────────────────────────────
const sendTokenResponse = (user, statusCode, res) => {
  const { access, refresh } = generateTokens(user._id);

  // Sanitise user output
  const userOutput = {
    _id          : user._id,
    name         : user.name,
    email        : user.email,
    role         : user.role,
    plan         : user.plan,
    organisation : user.organisation,
    city         : user.city,
    avatarUrl    : user.avatarUrl,
    monthlyAnalysisCount: user.monthlyAnalysisCount,
    monthlyAnalysisLimit: user.monthlyAnalysisLimit,
    createdAt    : user.createdAt,
  };

  res.status(statusCode).json({
    success     : true,
    accessToken : access,
    refreshToken: refresh,
    user        : userOutput,
  });
};

// ── POST /auth/register ───────────────────────────────────────────
exports.register = async (req, res) => {
  try {
    const { name, email, password, organisation, city } = req.body;

    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(409).json({ success: false, error: 'Email already registered.' });
    }

    const user = await User.create({ name, email, password, organisation, city });

    logger.info(`New user registered: ${email}`);
    sendTokenResponse(user, 201, res);
  } catch (err) {
    if (err.name === 'ValidationError') {
      const errors = Object.values(err.errors).map(e => e.message);
      return res.status(400).json({ success: false, error: errors.join(', ') });
    }
    logger.error(`Register error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Server error during registration.' });
  }
};

// ── POST /auth/login ──────────────────────────────────────────────
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required.' });
    }

    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }
    if (!user.isActive) {
      return res.status(401).json({ success: false, error: 'Account is deactivated.' });
    }

    user.lastLoginAt = new Date();
    await user.save({ validateBeforeSave: false });

    logger.info(`User logged in: ${email}`);
    sendTokenResponse(user, 200, res);
  } catch (err) {
    logger.error(`Login error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Server error during login.' });
  }
};

// ── POST /auth/refresh ────────────────────────────────────────────
exports.refresh = async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      return res.status(400).json({ success: false, error: 'Refresh token required.' });
    }

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user    = await User.findById(decoded.id);

    if (!user || !user.isActive) {
      return res.status(401).json({ success: false, error: 'Invalid refresh token.' });
    }

    const { access, refresh: newRefresh } = generateTokens(user._id);

    res.json({ success: true, accessToken: access, refreshToken: newRefresh });
  } catch (err) {
    res.status(401).json({ success: false, error: 'Invalid or expired refresh token.' });
  }
};

// ── GET /auth/me ──────────────────────────────────────────────────
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Server error.' });
  }
};

// ── PUT /auth/me ──────────────────────────────────────────────────
exports.updateMe = async (req, res) => {
  try {
    const allowed = ['name', 'organisation', 'city', 'avatarUrl'];
    const updates = {};
    allowed.forEach(field => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const user = await User.findByIdAndUpdate(req.user._id, updates, {
      new          : true,
      runValidators: true,
    });

    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Update failed.' });
  }
};

// ── PUT /auth/change-password ─────────────────────────────────────
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id).select('+password');

    if (!(await user.matchPassword(currentPassword))) {
      return res.status(401).json({ success: false, error: 'Current password is incorrect.' });
    }

    user.password = newPassword;
    await user.save();

    const { access } = generateTokens(user._id);
    res.json({ success: true, message: 'Password changed successfully.', accessToken: access });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Password change failed.' });
  }
};
