// ═══════════════════════════════════════════════════════════════
//  controllers/chatController.js — Document Q&A via NVIDIA NIM
// ═══════════════════════════════════════════════════════════════

const Document    = require('../models/Document');
const ChatSession = require('../models/ChatSession');
const logger      = require('../utils/logger');
const { answerQuestion } = require('../services/nvidiaService');

// ── POST /chat/ask — ask a question about a document ─────────────
exports.askQuestion = async (req, res) => {
  try {
    const { documentId, question, sessionId } = req.body;

    if (!documentId || !question?.trim()) {
      return res.status(400).json({ success: false, error: 'documentId and question are required.' });
    }

    // Load document with raw text (needed for context)
    const doc = await Document.findOne({
      _id       : documentId,
      uploadedBy: req.user._id,
      'analysis.status': 'completed',
    }).select('+rawText');

    if (!doc) {
      return res.status(404).json({
        success: false,
        error  : 'Document not found or analysis not yet complete.',
      });
    }

    // Retrieve or create chat session
    let session;
    if (sessionId) {
      session = await ChatSession.findOne({ _id: sessionId, user: req.user._id, document: documentId });
    }
    if (!session) {
      session = await ChatSession.create({
        user    : req.user._id,
        document: documentId,
        title   : question.slice(0, 60),
        messages: [],
      });
    }

    // Build conversation history for context
    const history = session.messages.map(m => ({ role: m.role, content: m.content }));

    // ── Call NVIDIA NIM ──────────────────────────────────────────
    const result = await answerQuestion({
      question,
      documentContext: doc.rawText,
      docName        : doc.originalName,
      conversationHistory: history,
    });

    // Append to session
    const userMsg = { role: 'user',      content: question,       createdAt: new Date() };
    const aiMsg   = {
      role      : 'assistant',
      content   : result.answer,
      confidence: result.confidence,
      pageRefs  : result.pageRefs,
      tokensUsed: result.tokensUsed,
      createdAt : new Date(),
    };

    session.messages.push(userMsg, aiMsg);
    session.totalTokens  += result.tokensUsed;
    session.lastActivity  = new Date();
    await session.save();

    res.json({
      success   : true,
      sessionId : session._id,
      answer    : result.answer,
      confidence: result.confidence,
      pageRefs  : result.pageRefs,
      tokensUsed: result.tokensUsed,
    });
  } catch (err) {
    logger.error(`Chat error: ${err.message}`);
    res.status(500).json({ success: false, error: 'Question answering failed.' });
  }
};

// ── GET /chat/sessions — list user's chat sessions ────────────────
exports.getSessions = async (req, res) => {
  try {
    const sessions = await ChatSession.find({ user: req.user._id, isActive: true })
      .sort({ lastActivity: -1 })
      .limit(20)
      .populate('document', 'originalName docType')
      .select('-messages');

    res.json({ success: true, sessions });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch sessions.' });
  }
};

// ── GET /chat/sessions/:id — get full session with messages ───────
exports.getSession = async (req, res) => {
  try {
    const session = await ChatSession.findOne({
      _id    : req.params.id,
      user   : req.user._id,
    })
    .populate('document', 'originalName docType pageCount analysis.overallConfidence');

    if (!session) {
      return res.status(404).json({ success: false, error: 'Session not found.' });
    }

    res.json({ success: true, session });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to fetch session.' });
  }
};

// ── DELETE /chat/sessions/:id ─────────────────────────────────────
exports.deleteSession = async (req, res) => {
  try {
    await ChatSession.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { isActive: false }
    );
    res.json({ success: true, message: 'Session archived.' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Delete failed.' });
  }
};
