// ═══════════════════════════════════════════════════════════════
//  models/Batch.js — Multi-Document Batch Analysis
// ═══════════════════════════════════════════════════════════════

const mongoose = require('mongoose');

const BatchSchema = new mongoose.Schema(
  {
    name        : { type: String, required: true, trim: true },
    createdBy   : { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    documentIds : [{ type: mongoose.Schema.Types.ObjectId, ref: 'Document' }],
    docCount    : { type: Number, default: 0 },

    status: {
      type   : String,
      enum   : ['pending', 'processing', 'completed', 'partial', 'failed'],
      default: 'pending',
    },

    // Merged AI analysis across all docs
    mergedAnalysis: {
      crossDocSummary    : { type: String, default: '' },
      commonThemes       : [String],
      conflictingClauses : [String],
      combinedDecisions  : { type: Number, default: 0 },
      combinedActions    : { type: Number, default: 0 },
      combinedAlerts     : { type: Number, default: 0 },
      averageConfidence  : { type: Number, default: 0 },
    },

    completedAt : Date,
    errorMessage: String,
    totalTokens : { type: Number, default: 0 },
  },
  { timestamps: true }
);

BatchSchema.index({ createdBy: 1 });
BatchSchema.index({ status: 1 });

module.exports = mongoose.model('Batch', BatchSchema);
