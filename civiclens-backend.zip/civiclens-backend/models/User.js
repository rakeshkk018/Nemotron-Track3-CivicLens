// ═══════════════════════════════════════════════════════════════
//  models/User.js — CivicLens User Model
// ═══════════════════════════════════════════════════════════════

const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const UserSchema = new mongoose.Schema(
  {
    // ── Identity ─────────────────────────────────────────────────
    name: {
      type     : String,
      required : [true, 'Name is required'],
      trim     : true,
      maxlength: [80, 'Name cannot exceed 80 characters'],
    },
    email: {
      type     : String,
      required : [true, 'Email is required'],
      unique   : true,
      lowercase: true,
      trim     : true,
      match    : [/^\S+@\S+\.\S+$/, 'Please enter a valid email'],
    },
    password: {
      type    : String,
      required: [true, 'Password is required'],
      minlength: [8, 'Password must be at least 8 characters'],
      select  : false, // never return password in queries by default
    },

    // ── Role & Status ─────────────────────────────────────────────
    role: {
      type    : String,
      enum    : ['citizen', 'analyst', 'admin'],
      default : 'citizen',
    },
    isActive: {
      type   : Boolean,
      default: true,
    },
    isEmailVerified: {
      type   : Boolean,
      default: false,
    },

    // ── Plan & Quota ─────────────────────────────────────────────
    plan: {
      type    : String,
      enum    : ['free', 'pro', 'enterprise'],
      default : 'free',
    },
    monthlyAnalysisCount : { type: Number, default: 0 },
    monthlyAnalysisLimit : { type: Number, default: 20 },
    lastResetDate        : { type: Date,   default: Date.now },

    // ── Profile extras ────────────────────────────────────────────
    organisation: { type: String, trim: true, default: '' },
    city        : { type: String, trim: true, default: '' },
    avatarUrl   : { type: String, default: '' },

    // ── Refresh token (stored hashed) ─────────────────────────────
    refreshToken: { type: String, select: false },

    // ── Timestamps ────────────────────────────────────────────────
    lastLoginAt: { type: Date },
    passwordChangedAt: { type: Date },
  },
  {
    timestamps: true,  // createdAt, updatedAt
    toJSON    : { virtuals: true },
    toObject  : { virtuals: true },
  }
);

// ── Indexes ──────────────────────────────────────────────────────
UserSchema.index({ email: 1 });
UserSchema.index({ role: 1, isActive: 1 });
UserSchema.index({ createdAt: -1 });

// ── Virtual: full document count ─────────────────────────────────
UserSchema.virtual('documents', {
  ref          : 'Document',
  localField   : '_id',
  foreignField : 'uploadedBy',
  count        : true,
});

// ── Pre-save: hash password ───────────────────────────────────────
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  if (!this.isNew) this.passwordChangedAt = new Date();
  next();
});

// ── Pre-save: monthly quota reset ────────────────────────────────
UserSchema.pre('save', function (next) {
  const now       = new Date();
  const lastReset = new Date(this.lastResetDate);
  if (
    now.getMonth() !== lastReset.getMonth() ||
    now.getFullYear() !== lastReset.getFullYear()
  ) {
    this.monthlyAnalysisCount = 0;
    this.lastResetDate        = now;
  }
  next();
});

// ── Instance method: compare password ────────────────────────────
UserSchema.methods.matchPassword = async function (enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

// ── Instance method: check quota ─────────────────────────────────
UserSchema.methods.hasAnalysisQuota = function () {
  return this.monthlyAnalysisCount < this.monthlyAnalysisLimit;
};

// ── Instance method: increment usage ─────────────────────────────
UserSchema.methods.incrementUsage = async function () {
  this.monthlyAnalysisCount += 1;
  return this.save({ validateBeforeSave: false });
};

// ── Static: find active users ─────────────────────────────────────
UserSchema.statics.findActive = function () {
  return this.find({ isActive: true });
};

module.exports = mongoose.model('User', UserSchema);
