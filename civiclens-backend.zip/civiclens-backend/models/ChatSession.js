// ═══════════════════════════════════════════════════════════════
//  models/ChatSession.js — Document Q&A Chat History
// ═══════════════════════════════════════════════════════════════

const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  role      : { type: String, enum: ['user', 'assistant'], required: true },
  content   : { type: String, required: true },
  confidence: { type: Number, min: 0, max: 100 },
  pageRefs  : [String],     // page references cited in the response
  tokensUsed: { type: Number, default: 0 },
  createdAt : { type: Date, default: Date.now },
}, { _id: true });

const ChatSessionSchema = new mongoose.Schema(
  {
    user        : { type: mongoose.Schema.Types.ObjectId, ref: 'User',     required: true },
    document    : { type: mongoose.Schema.Types.ObjectId, ref: 'Document', required: true },
    batchId     : { type: mongoose.Schema.Types.ObjectId, ref: 'Batch',    default: null },
    title       : { type: String, default: 'Untitled Session' },
    messages    : [MessageSchema],
    totalTokens : { type: Number, default: 0 },
    isActive    : { type: Boolean, default: true },
    lastActivity: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

ChatSessionSchema.index({ user: 1, document: 1 });
ChatSessionSchema.index({ lastActivity: -1 });

module.exports = mongoose.model('ChatSession', ChatSessionSchema);
