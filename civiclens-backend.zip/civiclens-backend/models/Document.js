// ═══════════════════════════════════════════════════════════════
//  models/Document.js — CivicLens Document Model
// ═══════════════════════════════════════════════════════════════

const mongoose        = require('mongoose');
const mongoosePaginate = require('mongoose-paginate-v2');

// ── Sub-schema: extracted entity ────────────────────────────────
const EntitySchema = new mongoose.Schema({
  text      : String,
  type      : { type: String, enum: ['date', 'amount', 'org', 'person', 'location', 'law', 'other'] },
  confidence: { type: Number, min: 0, max: 1 },
}, { _id: false });

// ── Sub-schema: action item ──────────────────────────────────────
const ActionItemSchema = new mongoose.Schema({
  title      : String,
  description: String,
  deadline   : Date,
  priority   : { type: String, enum: ['high', 'medium', 'low'], default: 'medium' },
  affectedGroup: String,
  pageRef    : String,
}, { _id: false });

// ── Sub-schema: key decision ─────────────────────────────────────
const DecisionSchema = new mongoose.Schema({
  title    : String,
  summary  : String,
  vote     : String,    // e.g. "7-2"
  effectiveDate: Date,
  pageRef  : String,
}, { _id: false });

// ── Sub-schema: alert ────────────────────────────────────────────
const AlertSchema = new mongoose.Schema({
  level   : { type: String, enum: ['info', 'warning', 'critical'], default: 'info' },
  message : String,
  pageRef : String,
}, { _id: false });

// ── Main Document schema ─────────────────────────────────────────
const DocumentSchema = new mongoose.Schema(
  {
    // ── File metadata ───────────────────────────────────────────
    originalName  : { type: String, required: true, trim: true },
    storedName    : { type: String, required: true },       // UUID filename on disk
    filePath      : { type: String, required: true },
    fileSize      : { type: Number, required: true },       // bytes
    mimeType      : { type: String, required: true },
    fileHash      : { type: String, index: true },          // SHA-256 for dedup

    // ── Document classification ──────────────────────────────────
    docType: {
      type   : String,
      enum   : ['council', 'budget', 'policy', 'emergency', 'scholarship', 'tender', 'gazette', 'other'],
      default: 'other',
    },
    language  : { type: String, default: 'en' },
    pageCount : { type: Number, default: 0 },
    wordCount : { type: Number, default: 0 },

    // ── Raw extracted text ───────────────────────────────────────
    rawText       : { type: String, select: false },        // not returned by default
    extractedChunks: [{ type: String }],                    // 1000-token chunks for RAG

    // ── AI Analysis ─────────────────────────────────────────────
    analysis: {
      status        : { type: String, enum: ['pending', 'processing', 'completed', 'failed'], default: 'pending' },
      startedAt     : Date,
      completedAt   : Date,
      errorMessage  : String,

      // NVIDIA NIM model used
      model         : { type: String, default: '' },
      processingMs  : { type: Number, default: 0 },

      // Summaries
      quickSummary  : { type: String, default: '' },
      factualSummary: { type: String, default: '' },
      biasFlags     : [String],

      // Confidence
      overallConfidence: { type: Number, min: 0, max: 100, default: 0 },

      // Structured extractions
      keyDecisions  : [DecisionSchema],
      actionItems   : [ActionItemSchema],
      alerts        : [AlertSchema],
      entities      : [EntitySchema],

      // Stats
      decisionCount : { type: Number, default: 0 },
      actionCount   : { type: Number, default: 0 },
      alertCount    : { type: Number, default: 0 },

      // Token usage from NVIDIA API
      tokensUsed    : {
        prompt    : { type: Number, default: 0 },
        completion: { type: Number, default: 0 },
        total     : { type: Number, default: 0 },
      },
    },

    // ── Multi-doc batch link ─────────────────────────────────────
    batchId       : { type: mongoose.Schema.Types.ObjectId, ref: 'Batch', default: null },

    // ── Ownership & visibility ────────────────────────────────────
    uploadedBy    : { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    isPublic      : { type: Boolean, default: false },
    tags          : [{ type: String, lowercase: true, trim: true }],
    viewCount     : { type: Number, default: 0 },

    // ── Soft delete ───────────────────────────────────────────────
    isDeleted     : { type: Boolean, default: false, index: true },
    deletedAt     : Date,
  },
  {
    timestamps: true,
    toJSON    : { virtuals: true },
    toObject  : { virtuals: true },
  }
);

// ── Compound indexes ──────────────────────────────────────────────
DocumentSchema.index({ uploadedBy: 1, isDeleted: 1 });
DocumentSchema.index({ docType: 1, 'analysis.status': 1 });
DocumentSchema.index({ tags: 1 });
DocumentSchema.index({ createdAt: -1 });
DocumentSchema.index({ originalName: 'text', 'analysis.quickSummary': 'text' });  // full-text

// ── Virtual: display label ───────────────────────────────────────
DocumentSchema.virtual('label').get(function () {
  const n = this.originalName.replace(/\.[^/.]+$/, '');
  return n.length > 60 ? n.slice(0, 57) + '…' : n;
});

// ── Virtual: is analysis ready ───────────────────────────────────
DocumentSchema.virtual('isReady').get(function () {
  return this.analysis.status === 'completed';
});

// ── Pre-find: exclude soft-deleted by default ─────────────────────
DocumentSchema.pre(/^find/, function () {
  if (!this._skipDeletedFilter) {
    this.where({ isDeleted: false });
  }
});

// ── Instance: soft delete ─────────────────────────────────────────
DocumentSchema.methods.softDelete = async function () {
  this.isDeleted = true;
  this.deletedAt = new Date();
  return this.save({ validateBeforeSave: false });
};

// Pagination plugin
DocumentSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('Document', DocumentSchema);
