// ═══════════════════════════════════════════════════════════════
//  server.js — CivicLens AI Backend  |  Node.js + Express + MongoDB + NVIDIA NIM
//  Version: 2.0.0
// ═══════════════════════════════════════════════════════════════

require('dotenv').config();

const express     = require('express');
const cors        = require('cors');
const helmet      = require('helmet');
const morgan      = require('morgan');
const compression = require('compression');
const rateLimit   = require('express-rate-limit');
const path        = require('path');
const fs          = require('fs');

const { connectDB } = require('./config/db');
const logger        = require('./utils/logger');
const routes        = require('./routes/index');
const { verifyAPIKey } = require('./services/nvidiaService');

// ── App ───────────────────────────────────────────────────────────
const app = express();
const PORT   = parseInt(process.env.PORT)   || 5000;
const PREFIX = process.env.API_PREFIX        || '/api/v1';

// ── Security middleware ───────────────────────────────────────────
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy    : false,
}));

// ── CORS ──────────────────────────────────────────────────────────
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin) || process.env.NODE_ENV === 'development') {
      return cb(null, true);
    }
    cb(new Error(`CORS blocked: ${origin}`));
  },
  credentials: true,
  methods    : ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
}));

// ── Body parsers ───────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Compression ───────────────────────────────────────────────────
app.use(compression());

// ── HTTP logging ──────────────────────────────────────────────────
app.use(morgan(
  process.env.NODE_ENV === 'production'
    ? ':remote-addr :method :url :status :res[content-length] - :response-time ms'
    : 'dev',
  { stream: { write: (msg) => logger.info(msg.trim()) } }
));

// ── Global rate limit ─────────────────────────────────────────────
app.use(rateLimit({
  windowMs : parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max      : parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  standardHeaders: true,
  legacyHeaders  : false,
  message  : { success: false, error: 'Too many requests. Please slow down.' },
}));

// ── Static files (for uploaded docs — serve with auth in prod) ────
const uploadDir = process.env.UPLOAD_DIR || './uploads';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// ── API routes ────────────────────────────────────────────────────
app.use(PREFIX, routes);

// ── Root ──────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    name       : 'CivicLens AI API',
    version    : '2.0.0',
    description: 'Government Document Intelligence — MongoDB + NVIDIA NIM',
    docs       : `${PREFIX}/health`,
    endpoints  : {
      auth     : `${PREFIX}/auth`,
      documents: `${PREFIX}/documents`,
      chat     : `${PREFIX}/chat`,
      admin    : `${PREFIX}/admin`,
    },
    nvidia     : {
      model  : process.env.NVIDIA_MODEL,
      baseUrl: process.env.NVIDIA_API_BASE_URL,
    },
  });
});

// ── Global error handler ─────────────────────────────────────────
app.use((err, req, res, _next) => {
  logger.error(`Unhandled error: ${err.message}`, { stack: err.stack });

  // Mongoose validation errors
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      error  : Object.values(err.errors).map(e => e.message).join(', '),
    });
  }
  // Mongoose duplicate key
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0];
    return res.status(409).json({
      success: false,
      error  : `${field || 'Field'} already exists.`,
    });
  }
  // JWT errors
  if (err.name === 'JsonWebTokenError') {
    return res.status(401).json({ success: false, error: 'Invalid token.' });
  }

  res.status(err.status || 500).json({
    success: false,
    error  : process.env.NODE_ENV === 'production' ? 'Internal server error.' : err.message,
  });
});

// ── Startup ───────────────────────────────────────────────────────
const start = async () => {
  logger.info('════════════════════════════════════════════');
  logger.info('  CivicLens AI Backend — Starting up…');
  logger.info('════════════════════════════════════════════');

  // Connect to MongoDB
  await connectDB();

  // Verify NVIDIA key
  verifyAPIKey();

  // Start server
  app.listen(PORT, () => {
    logger.info(`🚀 Server running on http://localhost:${PORT}`);
    logger.info(`📡 API prefix: ${PREFIX}`);
    logger.info(`🌍 Environment: ${process.env.NODE_ENV}`);
    logger.info(`🗄️  MongoDB: connected`);
    logger.info(`🤖 NVIDIA NIM: ${process.env.NVIDIA_MODEL}`);
    logger.info('════════════════════════════════════════════');
  });
};

start().catch((err) => {
  logger.error(`Fatal startup error: ${err.message}`);
  process.exit(1);
});

// ── Handle uncaught exceptions ────────────────────────────────────
process.on('uncaughtException',  (err) => { logger.error(`Uncaught Exception: ${err.message}`);  process.exit(1); });
process.on('unhandledRejection', (err) => { logger.error(`Unhandled Rejection: ${err.message}`); process.exit(1); });

module.exports = app;
